package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.UserDao;
import com.cdac.dto.User;

@Service
public class UserServiceImple implements UserService {
	
	@Autowired
	private UserDao userDao;
	@Override
	public void addUser(User user) {
		System.out.println("inside userservice IMple");
      userDao.insertUser(user);
		
	}
	@Override
	public boolean findUser(User user) {
		return userDao.checkUser(user);
	}
	@Override
	public User findUser(int user_id) {
		return userDao.getUser(user_id);

		
	}
	@Override
	public List<User> selectAllbyid(int user_id) {
		
		return userDao.selectAllid(user_id);
	}
	
	
}
