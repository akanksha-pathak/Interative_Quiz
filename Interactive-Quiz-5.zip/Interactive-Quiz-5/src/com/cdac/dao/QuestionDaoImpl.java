package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Question;

@Repository
public class QuestionDaoImpl implements QuestionDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public List<Question> selectAll(int qno) {
		
		List<Question> queList = hibernateTemplate.execute(new HibernateCallback<List<Question>>() {

			@Override
			public List<Question> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Question");
				List<Question> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return queList;
	}

	@Override
	public Question findQuestion(int qno) {
		Question question = hibernateTemplate.execute(new HibernateCallback<Question>() {

			@Override
			public Question doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Question qe = (Question)session.get(Question.class, qno);
				tr.commit();
				session.flush();
				session.close();
				return qe;
			}
			
		});
		return question;
	}
}
