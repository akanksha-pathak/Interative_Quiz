package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Question;

public interface QuestionDao {
	Question findQuestion(int qno);
	List<Question> selectAll(int qno);
}
