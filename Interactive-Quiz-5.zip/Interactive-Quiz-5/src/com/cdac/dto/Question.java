package com.cdac.dto;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "questions")
public class Question {
	@Id
	@GeneratedValue
	@Column(name = "qno")
	private int qno;
	@Column(name = "ques")
	private String ques;
	@Column(name = "op1")
	private String op1;
	@Column(name = "op2")
	private String op2;
	@Column(name = "op3")
	private String op3;
	@Column(name = "op4")
	private String op4;
	@Column(name = "correct_Ans")
	private int correct_Ans;
	@Column(name = "user_ans")
	private int user_ans;
	@Column(name = "score")
	private int score;

	public int getUser_ans() {
		return user_ans;
	}

	public void setUser_ans(int user_ans) {
		this.user_ans = user_ans;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public Question() {
		super();
	}

	public int getQno() {
		return qno;
	}

	public void setQno(int qno) {
		this.qno = qno;
	}

	public String getQues() {
		return ques;
	}

	public void setQues(String ques) {
		this.ques = ques;
	}

	public String getOp1() {
		return op1;
	}

	public void setOp1(String op1) {
		this.op1 = op1;
	}

	public String getOp2() {
		return op2;
	}

	public void setOp2(String op2) {
		this.op2 = op2;
	}

	public String getOp3() {
		return op3;
	}

	public void setOp3(String op3) {
		this.op3 = op3;
	}

	public String getOp4() {
		return op4;
	}

	public void setOp4(String op4) {
		this.op4 = op4;
	}

	public int getCorrect_Ans() {
		return correct_Ans;
	}

	public void setCorrect_Ans(int correct_Ans) {
		this.correct_Ans = correct_Ans;
	}

}