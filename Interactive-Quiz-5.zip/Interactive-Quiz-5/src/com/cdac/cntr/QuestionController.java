package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.Question;
import com.cdac.dto.User;
import com.cdac.service.QuestionService;

@Controller
public class QuestionController {
	
	@Autowired
	private QuestionService questionService;
	
	@RequestMapping(value = "/question_page.htm",method = RequestMethod.GET)
	public String allQuestions(ModelMap map,HttpSession session) {
			
		System.out.println("in the method");
		int qno = 1;//((Question)session.getAttribute("questions")).getQno();
		List<Question> li = questionService.selectAll(qno);
		System.out.println(li);
		map.put("queList", li);
		return "Exam";
	}
	
}
